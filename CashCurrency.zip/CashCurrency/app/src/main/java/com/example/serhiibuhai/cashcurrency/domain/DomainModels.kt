package com.example.serhiibuhai.cashcurrency.domain

import com.example.serhiibuhai.cashcurrency.data.Currency

data class ExchangeRatePB(
    val baseCurrency: Currency,
    val currency: Currency,
    val sellRate: Double,
    val purchaseRate: Double
)

data class ExchangeRateNB(
    val txt: String,
    val rate: Double,
    val cc: String
)