package com.example.serhiibuhai.cashcurrency.data

import com.example.serhiibuhai.cashcurrency.domain.Api
import com.google.gson.Gson
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object P24APIProvider {

    private val PBApi: Api = Retrofit.Builder()
        .baseUrl(Api.BASE_URL_PB)
        .addConverterFactory(GsonConverterFactory.create(Gson()))
        .build()
        .create(Api::class.java)

    private val NBApi: Api = Retrofit.Builder()
        .baseUrl(Api.BASE_URL_NB)
        .addConverterFactory(GsonConverterFactory.create(Gson()))
        .build()
        .create(Api::class.java)

    fun provideP24API(): Api = PBApi

    fun provideNBAPI(): Api = NBApi

}