package com.example.serhiibuhai.cashcurrency.data

import com.example.serhiibuhai.cashcurrency.domain.PBExchangeRateRepository
import com.example.serhiibuhai.cashcurrency.domain.Api

class P24ExchangeRateRepository(private val api: Api) : PBExchangeRateRepository {
    override fun query(date: String): List<APIExchangeRate> {
        val response = api.getPBCurrency(date).execute()
        if (response.isSuccessful.not()) {
            throw Exception("Request was not successful. Error code: ${response.code()}")
        }
        return response.body()?.APIExchangeRate?.filter {
            it.currency != null && it.baseCurrency != null
        } ?: emptyList()
    }
}