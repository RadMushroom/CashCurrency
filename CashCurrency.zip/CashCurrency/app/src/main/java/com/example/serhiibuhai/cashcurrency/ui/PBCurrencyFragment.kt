package com.example.serhiibuhai.cashcurrency.ui


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import com.example.serhiibuhai.cashcurrency.R
import kotlinx.android.synthetic.main.fragment_pbcurrency.*
import java.text.SimpleDateFormat
import java.util.*


class PBCurrencyFragment : Fragment() {

    private lateinit var viewModel: PBCurrencyViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_pbcurrency, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val c = Calendar.getInstance()
        val dateformat = SimpleDateFormat("dd.MM.yyyy")
        val datetime = dateformat.format(c.time)
        dateTextView.text = datetime
        viewModel = ViewModelProviders.of(this).get(PBCurrencyViewModel::class.java)

    }

    fun pickDate(v: View) {
//        val newFragment: DialogFragment = DatePickerFragment()
//        newFragment.show(fragmentManager, getString(R.string.datepicker))
    }

    fun processDatePickerResult(year: Int, month: Int, day: Int) {
        val month_string = Integer.toString(month + 1)
        val day_string = Integer.toString(day)
        val year_string = Integer.toString(year)
        val dateMessage = "$day_string.$month_string.$year_string"
        dateTextView.text = dateMessage
    }
}
