package com.example.serhiibuhai.cashcurrency.domain

import com.example.serhiibuhai.cashcurrency.data.NBExchangeRate
import com.example.serhiibuhai.cashcurrency.data.PBCurrencyResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface Api {
    companion object {
        const val BASE_URL_PB = " https://api.privatbank.ua"
        const val BASE_URL_NB = "https://bank.gov.ua/NBUStatService/v1/statdirectory"
    }

    @GET("/p24api/exchange_rates?date={date}")
    fun getPBCurrency(@Path("date") date: String): Call<PBCurrencyResponse>

    @GET("//exchange?json")
    fun getTodayNBCurrency(): Call<List<NBExchangeRate>>

    @GET("/exchange?date={date}&json")
    fun getArchiveNBCurrency(@Path("date") date: String): Call<List<NBExchangeRate>>

}