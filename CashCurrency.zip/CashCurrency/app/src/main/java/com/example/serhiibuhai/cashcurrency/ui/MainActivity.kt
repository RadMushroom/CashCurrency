package com.example.serhiibuhai.cashcurrency.ui

import android.os.Bundle
import com.example.serhiibuhai.cashcurrency.R

class MainActivity : BaseActivity() {

    override fun getContentView(): Int = R.layout.activity_main

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}
