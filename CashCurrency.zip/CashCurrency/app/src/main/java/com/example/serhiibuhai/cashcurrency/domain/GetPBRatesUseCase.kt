package com.example.serhiibuhai.cashcurrency.domain

class GetPBRatesUseCase(private val PBExchangeRateRepository: PBExchangeRateRepository) {
    fun execute(date: String): List<ExchangeRatePB> {
        val result = PBExchangeRateRepository.query(date)
        return result.filter {
            it.sellRate != null && it.purchaseRate != null
        }.map {
            ExchangeRatePB(
                it.baseCurrency,
                it.currency,
                it.sellRate!!,
                it.purchaseRate!!
            ) // Use force unwrap according to filtering operation above
        }
    }
}