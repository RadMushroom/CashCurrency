package com.example.serhiibuhai.cashcurrency.domain

import com.example.serhiibuhai.cashcurrency.data.APIExchangeRate

interface PBExchangeRateRepository {
    fun query(date: String): List<APIExchangeRate>
}