package com.example.serhiibuhai.cashcurrency.ui

import androidx.lifecycle.ViewModel

class PBCurrencyViewModel : ViewModel() {

}