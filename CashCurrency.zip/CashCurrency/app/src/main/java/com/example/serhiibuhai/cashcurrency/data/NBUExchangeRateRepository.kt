package com.example.serhiibuhai.cashcurrency.data

import com.example.serhiibuhai.cashcurrency.domain.NBExchangeRateRepository
import com.example.serhiibuhai.cashcurrency.domain.Api

class NBUExchangeRateRepository(private val api: Api) : NBExchangeRateRepository{
    override fun queryToday(): List<NBExchangeRate> {
        val response = api.getTodayNBCurrency().execute()
        if (response.isSuccessful.not()) {
            throw Exception("Request was not successful. Error code: ${response.code()}")
        }
        return response.body() ?: emptyList()
    }

    override fun queryArchive(date: String): List<NBExchangeRate> {
        val response = api.getArchiveNBCurrency(date).execute()
        if (response.isSuccessful.not()) {
            throw Exception("Request was not successful. Error code: ${response.code()}")
        }
        return response.body() ?: emptyList()
    }
}