package com.example.serhiibuhai.cashcurrency.domain

class GetNBURatesUseCase(private val exchangeRateRepository: NBExchangeRateRepository) {

    fun executeArchive(date: String): List<ExchangeRateNB> {
        val result = exchangeRateRepository.queryArchive(date)
        return result.map {
            ExchangeRateNB(
                it.txt,
                it.rate,
                it.cc
            )
        }
    }
}