package com.example.serhiibuhai.cashcurrency.domain

import com.example.serhiibuhai.cashcurrency.data.NBExchangeRate

interface NBExchangeRateRepository {
    fun queryToday(): List<NBExchangeRate>
    fun queryArchive(date: String): List<NBExchangeRate>
}