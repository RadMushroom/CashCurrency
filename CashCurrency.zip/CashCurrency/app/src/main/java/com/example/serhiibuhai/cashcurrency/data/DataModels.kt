package com.example.serhiibuhai.cashcurrency.data

import com.google.gson.annotations.SerializedName

data class PBCurrencyResponse(
    val date: String,
    val bank: String,
    val baseCurrency: Int,
    val baseCurrencyLit: String,
    val APIExchangeRate: List<APIExchangeRate>
)

data class APIExchangeRate(
    val baseCurrency: Currency,
    val currency: Currency,
    val sellRateNB: Double,
    val purchaseRateNB: Double,
    val sellRate: Double?,
    val purchaseRate: Double?
)

enum class Currency {
    @SerializedName("USD")
    USD,
    @SerializedName("EUR")
    EUR,
    @SerializedName("RUR")
    RUR,
    @SerializedName("CHF")
    CHF,
    @SerializedName("GBP")
    GBP,
    @SerializedName("PLZ")
    PLZ,
    @SerializedName("SEK")
    SEK,
    @SerializedName("XAU")
    XAU,
    @SerializedName("CAD")
    CAD
}

data class NBExchangeRate(
    val r030: Int,
    val txt: String,
    val rate: Double,
    val cc: String,
    val exchangeDate: String)